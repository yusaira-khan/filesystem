#include "sfs_api.h"

void mksfs(int fresh) {
	//Implement mksfs here	
	return;
}

int sfs_getnextfilename(char *fname) {

	//Implement sfs_getnextfilename here	
	return 0;
}


int sfs_getfilesize(const char* path) {

	//Implement sfs_getfilesize here	
	return 0;
}

int sfs_fopen(char *name) {

	//Implement sfs_fopen here	
	return 0;
}

int sfs_fclose(int fileID){

	//Implement sfs_fclose here	
	return 0;
}

int sfs_fread(int fileID, char *buf, int length){

	//Implement sfs_fread here	
	return 0;
}

int sfs_fwrite(int fileID, const char *buf, int length){

	//Implement sfs_fwrite here	
	return 0;
}

int sfs_fseek(int fileID, int loc){

	//Implement sfs_fseek here	
	return 0;
}

int sfs_remove(char *file) {

	//Implement sfs_remove here	
	return 0;
}
